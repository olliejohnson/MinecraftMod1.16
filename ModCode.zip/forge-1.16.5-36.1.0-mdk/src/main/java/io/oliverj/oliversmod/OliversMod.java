package io.oliverj.oliversmod;

import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(OliversMod.MOD_ID)
public class OliversMod {
	public static final String MOD_ID = "om";
	public static final ItemGroup MOD_GROUP = new ModGroup("modtab");
	
	public OliversMod() {
		
		ModItems.ITEMS.register(FMLJavaModLoadingContext.get().getModEventBus());
		ModBlocks.BLOCKS.register(FMLJavaModLoadingContext.get().getModEventBus());
	}
	
	public static class ModGroup extends ItemGroup {

		public ModGroup(String label) {
			super(label);
		}

		@Override
		public ItemStack makeIcon() {
			return ModItems.GALAXY_STEEL.get().getDefaultInstance();
		}
		}
	
	}
