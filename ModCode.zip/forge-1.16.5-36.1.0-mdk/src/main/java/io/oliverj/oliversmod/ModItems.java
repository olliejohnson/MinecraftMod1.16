package io.oliverj.oliversmod;

import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModItems {

    //The ITEMS deferred register in which you can register items.
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, OliversMod.MOD_ID);

    //Register the tutorial dust with "tutorial_dust" as registry name and default properties
    public static final RegistryObject<Item> COPPER_INGOT = ITEMS.register("copper_ingot", () -> new Item(new Item.Properties().tab(OliversMod.MOD_GROUP)));
    public static final RegistryObject<Item> STEEL = ITEMS.register("steel", () -> new Item(new Item.Properties().tab(OliversMod.MOD_GROUP)));
    public static final RegistryObject<Item> IRON_OXIDE = ITEMS.register("iron_oxide", () -> new Item(new Item.Properties().tab(OliversMod.MOD_GROUP)));
    public static final RegistryObject<Item> GALAXY_STEEL = ITEMS.register("galaxy_steel", () -> new Item(new Item.Properties().tab(OliversMod.MOD_GROUP)));
    public static final RegistryObject<Item> SUN_COPPER = ITEMS.register("sun_copper", () -> new Item(new Item.Properties().tab(OliversMod.MOD_GROUP)));
    public static final RegistryObject<Item> COPPER_ORE = ITEMS.register("copper_ore", () -> new BlockItem(ModBlocks.COPPER_ORE.get(), new Item.Properties().tab(OliversMod.MOD_GROUP)));

}
